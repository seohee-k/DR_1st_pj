#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from sensor_msgs.msg import Image
from yolov8_msgs.msg import Yolov8Inference
from cv_bridge import CvBridge
import cv2
import numpy as np
import tkinter as tk
from PIL import Image as PILImage, ImageTk
import threading
import time

# ... 생략된 import 부분은 기존 그대로 유지 ...

class TurtleBotYoloGui(Node):
    def __init__(self):
        super().__init__('turtlebot3_gui_yolo')
        self.publisher_ = self.create_publisher(Twist, '/cmd_vel', 10)
        self.image_sub = self.create_subscription(Image, '/pi_camera/image_raw', self.image_callback, 10)
        self.yolo_sub = self.create_subscription(Yolov8Inference, '/yolov8/detections', self.yolo_callback, 10)

        self.br = CvBridge()
        self.latest_image = None
        self.latest_mask = None
        self.latest_yolo_image = None

        self.auto_mode = True
        self.last_mode = 'center'
        self.linear_speed = 0.15
        self.angular_speed = 0.5

        self.last_pause_time = 0
        self.status_text = "주행 중"  # 🟢 현재 상태를 GUI에 출력할 변수
        

    def image_callback(self, data):
        img = self.br.imgmsg_to_cv2(data, desired_encoding='bgr8')
        self.latest_image = img.copy()
        if self.auto_mode:
            self.process_line_following(img)

    def yolo_callback(self, msg):
        if self.latest_image is None:
            return

        img = self.latest_image.copy()
        detected = False

        for det in msg.yolov8_inference:
            class_name = det.class_name.lower()
            self.get_logger().info(f"[YOLO] Detected: {class_name}")

            if class_name in ["stop", "stop_sign", "stop sign"]:
                x1, y1 = int(det.left), int(det.top)
                x2, y2 = int(det.right), int(det.bottom)
                cv2.rectangle(img, (x1, y1), (x2, y2), (0, 255, 0), 2)
                cv2.putText(img, class_name, (x1, y1 - 5),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

                area = (x2 - x1) * (y2 - y1)
                self.get_logger().info(f"[YOLO] Bounding box area: {area}")

                if area > 26000 and (time.time() - self.last_pause_time) > 5:
                    self.get_logger().info("[YOLO] STOP SIGN 감지됨 → 정지 요청")
                    self.pause_requested = True
                    self.last_pause_time = time.time()
                    self.status_text = "STOP SIGN 감지 → 정지 중..."  # ⛔ 상태 업데이트
                    detected = True

        if not detected:
            self.pause_requested = False

        self.latest_yolo_image = img

    def process_line_following(self, img):
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        lower_yellow = np.array([22, 150, 150])
        upper_yellow = np.array([32, 255, 255])
        mask = cv2.inRange(hsv, lower_yellow, upper_yellow)
        self.latest_mask = mask.copy()

        h, w = mask.shape
        roi = mask[int(h * 0.6):, :]
        left_roi = roi[:, :int(w * 0.2)]
        right_roi = roi[:, int(w * 0.8):]

        M_left = cv2.moments(left_roi)
        M_right = cv2.moments(right_roi)
        if hasattr(self, "pause_requested") and self.pause_requested:
            self.get_logger().info("[MAIN] 3초 정지 중...")
            stop_twist = Twist()
            stop_twist.linear.x = 0.0
            stop_twist.angular.z = 0.0
            self.publisher_.publish(stop_twist)
            time.sleep(3)

            self.pause_requested = False
            self.status_text = "주행 재개"  # ✅ 상태 업데이트
            self.get_logger().info("[MAIN] 주행 재개")
            return

        twist = Twist()

        if M_left['m00'] > 0 and M_right['m00'] > 0:
            cx_left = int(M_left['m10'] / M_left['m00'])
            cx_right = int(M_right['m10'] / M_right['m00']) + int(w * 0.8)
            cx = (cx_left + cx_right) // 2
            err = cx - w // 2
            twist.linear.x = self.linear_speed
            twist.angular.z = -float(err) / 120.0
            self.last_mode = 'center'
        elif M_right['m00'] > 0:
            twist.linear.x = 0.1
            twist.angular.z = 0.3
            self.last_mode = 'right'
        elif M_left['m00'] > 0:
            twist.linear.x = 0.1
            twist.angular.z = -0.3
            self.last_mode = 'left'
        else:
            twist.linear.x = 0.05
            twist.angular.z = 0.2
            self.last_mode = 'lost'

        self.publisher_.publish(twist)

    def send_manual_cmd(self, lin, ang):
        if self.auto_mode:
            return
        twist = Twist()
        twist.linear.x = lin
        twist.angular.z = ang
        self.publisher_.publish(twist)

    def stop(self):
        self.send_manual_cmd(0.0, 0.0)

    def toggle_mode(self):
        self.auto_mode = not self.auto_mode
        self.status_text = "자동 주행 ON" if self.auto_mode else "수동 조작 중"
        self.get_logger().info(f"[모드 전환] 자동 모드: {'ON' if self.auto_mode else 'OFF'}")
        if self.auto_mode:
            self.stop()

# --------------------------------------------
# 🖥️ GUI
# --------------------------------------------

def run_gui(node: TurtleBotYoloGui):
    win = tk.Tk()
    win.title("TurtleBot3 GUI + YOLOv8")

    speed_var = tk.DoubleVar(value=node.linear_speed)

    def update_speed(val):
        node.linear_speed = float(val)

    tk.Label(win, text="속도 조절").pack()
    tk.Scale(win, from_=0.05, to=0.5, resolution=0.01, orient=tk.HORIZONTAL,
             variable=speed_var, command=update_speed).pack()

    btn_frame = tk.Frame(win)
    btn_frame.pack()

    tk.Button(btn_frame, text="↑ 전진", width=10,
              command=lambda: node.send_manual_cmd(node.linear_speed, 0.0)).grid(row=0, column=1)
    tk.Button(btn_frame, text="← 좌회전", width=10,
              command=lambda: node.send_manual_cmd(0.0, node.angular_speed)).grid(row=1, column=0)
    tk.Button(btn_frame, text="정지", width=10, command=node.stop).grid(row=1, column=1)
    tk.Button(btn_frame, text="→ 우회전", width=10,
              command=lambda: node.send_manual_cmd(0.0, -node.angular_speed)).grid(row=1, column=2)
    tk.Button(btn_frame, text="↓ 후진", width=10,
              command=lambda: node.send_manual_cmd(-node.linear_speed, 0.0)).grid(row=2, column=1)

    def toggle():
        node.toggle_mode()
        btn_mode.config(text="자동 → 수동" if not node.auto_mode else "수동 → 자동")

    btn_mode = tk.Button(win, text="수동 → 자동", command=toggle)
    btn_mode.pack(pady=5)

    # 상태 표시 텍스트
    status_label = tk.Label(win, text="주행 상태", font=("Arial", 14))
    status_label.pack(pady=5)

    # 이미지
    frame = tk.Frame(win)
    frame.pack()

    label_line = tk.Label(frame)
    label_line.pack(side=tk.LEFT)

    label_yolo = tk.Label(frame)
    label_yolo.pack(side=tk.RIGHT)

    def update_view():
        status_label.config(text=node.status_text)

        if node.latest_mask is not None:
            mask_bgr = cv2.cvtColor(node.latest_mask, cv2.COLOR_GRAY2BGR)
            cv2.putText(mask_bgr, f"Mode: {node.last_mode}", (10, 40),
                        cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 255, 0), 2)
            img_rgb = cv2.cvtColor(mask_bgr, cv2.COLOR_BGR2RGB)
            im = PILImage.fromarray(img_rgb)
            imgtk = ImageTk.PhotoImage(image=im)
            label_line.imgtk = imgtk
            label_line.configure(image=imgtk)

        if node.latest_yolo_image is not None:
            yolo_rgb = cv2.cvtColor(node.latest_yolo_image, cv2.COLOR_BGR2RGB)
            im2 = PILImage.fromarray(yolo_rgb)
            imgtk2 = ImageTk.PhotoImage(image=im2)
            label_yolo.imgtk = imgtk2
            label_yolo.configure(image=imgtk2)

        label_line.after(50, update_view)

    update_view()
    win.mainloop()

def main(args=None):
    rclpy.init(args=args)
    node = TurtleBotYoloGui()
    gui_thread = threading.Thread(target=run_gui, args=(node,), daemon=True)
    gui_thread.start()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
